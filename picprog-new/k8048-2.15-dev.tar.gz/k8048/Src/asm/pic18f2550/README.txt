k8048 reference for the PIC18F2550
----------------------------------

Function        Pin
--------        --------

LD1		RA0 (2)
LD2		RA1 (3)
LD3		RA2 (4)
LD4		RA3 (5)
LD5		RA4 (6)
LD6		RA5 (7)

SW1		RB0 (21)
SW2		RB1 (22)
SW3		RB2 (23)
SW4		RB4 (25)
