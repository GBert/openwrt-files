k8048 reference for the PIC16F627
---------------------------------

Function	Pin
--------	--------
LD1		RB0 (6)
LD2		RB1 (7)
LD3		RB2 (8)
LD4		RB3 (9)
LD5		RB4 (10)
LD6		RB5 (11)

PGC		RB6 (12)
PGD		RB7 (13)

SW1		RA0 (17)
SW2		RA1 (18)
SW3		RA2 (1)
SW4		RA3 (2)

		RA4 (3)
VPP		RA5 (4)
OSC2		RA6 (15)
OSC1		RA7 (16)

GND		VSS (5)
+5V		VDD (14)
