k8048 reference for the PIC18F1320
----------------------------------

Function	Pin
--------	--------
LD1		RA2 (6)
LD2		RA3 (7)
LD3		RB0 (8)
LD4		RB1 (9)
LD5		RB4 (10)
LD6		RB5 (11)

PGC		RB6 (12)
PGD		RB7 (13)

SW1		RB2 (17)
SW2		RB3 (18)
SW3		RA0 (1)
SW4		RA1 (2)

		RA4 (3)
VPP		RA5 (4)
OSC2		RA6 (15)
OSC1		RA7 (16)

GND		VSS (5)
+5V		VDD (14)
