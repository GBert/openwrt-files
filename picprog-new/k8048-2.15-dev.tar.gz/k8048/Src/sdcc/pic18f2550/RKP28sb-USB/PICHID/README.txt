Origin:
	http://www.microchip.com/forums/m170553.aspx
	http://www.nutsvolts.com/index.php?/magazine/article/usb_device_control
	http://www.nutsvolts.com/uploads/magazine_downloads/200606-Enzmann-USB.zip

Added:
	lgpl-2.1.txt

Changes:
	Removed some files
	Applied compilation fixes for sdcc 3.3.0
	Edited USB descriptors
	Re-arranged code slightly
	Used INDENT(1) to tidy
